let College=(props)=>{
return(
    <>
    <h1>College Name:{props.nm}</h1>
    <h1>College Seats:{props.seats}</h1>
    <h1>College Fees:{props.fs}</h1>
    </>
)
}
export default College