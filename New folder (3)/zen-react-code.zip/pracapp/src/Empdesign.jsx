const Empdesign =(props)=>{
return(
    <>
    
    <tr>
        <td>{props.eno}</td>
        <td>{props.nm}</td>
        <td>{props.dsg}</td>
        <td>{props.sal}</td>
    </tr>
   
    </>
)
}
export default Empdesign