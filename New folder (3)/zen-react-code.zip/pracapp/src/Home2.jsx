const Home2=()=>{
    return(
        <>
        <h1 className="data">Iam Home2</h1>
        </>
    )
    }
    export default Home2