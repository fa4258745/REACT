const Home1=()=>{
return(
    <>
     <h1 id="theme">Iam Home1</h1>
    </>
)
}
export default Home1