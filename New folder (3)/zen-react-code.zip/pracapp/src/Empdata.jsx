const Empdata=[
    {
        "empno":12,
        "name":"Zainab",
        "designation":"Senior Devloper",
        "salary":99000
    },
    {
        "empno":12,
        "name":"Zainab",
        "designation":"Senior Devloper",
        "salary":99000
    },
    {
        "empno":12,
        "name":"Zainab",
        "designation":"Senior Devloper",
        "salary":99000
    }
]
export default Empdata