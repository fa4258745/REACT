//Day 1:
//Creating our First React app:
//Day 2:
//Printing Hello World
//Day 3:
// const name="Ananya";
// const age=22;
// const lpa=7;
//Inserting a Large Block of HTML code:
// const tbl = <table border={2} cellPadding={10} cellSpacing={5}>
//   <thead>
//     <tr>
//       <th>Sr. No.</th>
//       <th>Author</th>
//       <th>Book</th>
//     </tr>
//   </thead>
//   <tbody>
//     <tr>
//       <td>01</td>
//       <td>Ruskin Bond</td>
//       <td>The Whistling School Boy</td>
//     </tr>
//     <tr>
//       <td>02</td>
//       <td>Preety Shenoy</td>
//       <td>Life is what you make it</td>
//     </tr>
//     <tr>
//       <td>03</td>
//       <td>R.K. Narayan</td>
//       <td>Malgudi Days</td>
//     </tr>
//     <tr>
//       <td>04</td>
//       <td>Colleen Hoover</td>
//       <td>It Ends With Us</td>
//     </tr>
//     <tr>
//       <td>05</td>
//       <td>Haruki Murakami</td>
//       <td>Men Without Women</td>
//     </tr>
//   </tbody>
// </table>

// let App = () => {
//   return (
//     // Expression in JSX:
//     <h3>{tbl}</h3>
//Wrapping html tags in one element: One Top Level Element!
//  <div>
//  <h1>Hello</h1>
//  <h1>Hello</h1>
//  <h1>Hello</h1>
//  <h1>Hello</h1>
//  </div>
// Fragment tag:
//  <>
//  <h1>Hello</h1>
//  <h1>Hello</h1>
//  <h1>Hello</h1>
//  <h1>Hello</h1>
//  </>

//   )
// }
//Day 4:
//Creating our first jsx component Cybrom.jsx:
// import Cybrom from "./Cybrom";
// import Header from "./Header";
// import Data from "./Data";
// import Footer from "./Footer";
// let App = () => {
//   return (
//     <>
//       <Cybrom />
//       <Header />
//       <Data />
//       <Footer />
//     </>
//   )
// }
//DAY 5:
// *Passing props through variables:
// const name="Atiya"
// const seat=45
// const fees=55000
//*Passing props through object:
// const Colleges={
//   name:"Hania",
//   seats:34,
//   fee:66000
// }
// import College from "./College";
// let App=()=>{
// return(
//   <>
//   {/* Passing props as values */}
//  {/* <College nm="Zainab" seats="89" fs="77000"/> */}
//  <College nm={name} seats={seat} fs={fees}/>
//  <College nm={Colleges.name} seats={Colleges.seats} fs={Colleges.fee}/>
//   </>
// )
// }
// export default App;
// //DAY 6:
// import Empdata from "./Empdata";
// import Empdesign from "./Empdesign";
// const App=()=>{
//   const ans=Empdata.map((key)=> <Empdesign
//   eno={key.empno} nm={key.name} dsg={key.designation} sal={key.salary} />
// )
// return(
//   <>
//   <h1>WELCOME !!!!!</h1>
// <table border={2}>
// <tr>
//   <th>ENO.</th>
//   <th>Name :</th>
//   <th>Designation :</th>
//   <th>Salary :</th>
// </tr>
// <tbody>
// {ans}
// </tbody>

// </table>
//   </>
// )
// }
// export default App
//Day 7:
// import { BrowserRouter, Routes, Route } from "react-router-dom"
// import Home from "./Pages/Home"
// import Contact from "./Pages/Contact"
// import About from "./Pages/About"
// import Layout from "./Layout"
// import Product from "./Pages/Product"
// import NotFound from "./Pages/NotFound"
// const App = () => {
//   return (
//     <>
//       <BrowserRouter>
//         <Routes>
//           <Route path="/" element={<Layout />}>
//             <Route index element={<Home />} />
//             <Route path="home" element={<Home />} />
//             <Route path="about" element={<About />} />
//             <Route path="contact" element={<Contact />} />
//             <Route path="product" element={<Product />} />
//             <Route path="*" element={<NotFound />} />
//           </Route>
//         </Routes>
//       </BrowserRouter>
//     </>
//   )
// }
// export default App
// Day 8:
// import "./style.css"
// import Home1 from "./Home1";
// import Home2 from "./Home2";
// import BoxTask from "./BoxTask";
// const App = () => {
//   return (
//     <>
//       <BoxTask />
//       {/* <Home1 />
//       <Home2 /> */}
//     </>
//   );
// };
// export default App;
// Day 9 :
// import Reactboot from "./Reactboot"
// import 'bootstrap/dist/css/bootstrap.min.css';
// import Container from 'react-bootstrap/Container';
// import Nav from 'react-bootstrap/Nav';
// import Navbar from 'react-bootstrap/Navbar';

// import Carousel from 'react-bootstrap/Carousel';

// import Button from 'react-bootstrap/Button';
// import Card from 'react-bootstrap/Card';

// import img1 from "./Images/n1.png"
// import img2 from "./Images/n2.png"
// import img3 from "./Images/n3.png"
// const App = () => {
//   return (
//     <>
//    <Reactboot />
//    <Navbar bg="primary" data-bs-theme="dark">
//         <Container>
//           <Navbar.Brand href="#home">Navbar</Navbar.Brand>
//           <Nav className="me-auto">
//             <Nav.Link href="#home">Home</Nav.Link>
//             <Nav.Link href="#features">Features</Nav.Link>
//             <Nav.Link href="#pricing">Pricing</Nav.Link>
//             <Nav.Link href="#pricing">About</Nav.Link>
//             <Nav.Link href="#pricing">Products</Nav.Link>
//           </Nav>
//         </Container>
//       </Navbar>


//       <Carousel>
//       <Carousel.Item>
//       <img src={img1} width="100%" height="300"/>
//         <Carousel.Caption>
//           <h3>First slide label</h3>
//           <p>Nulla vitae elit libero, a pharetra augue mollis interdum.</p>
//         </Carousel.Caption>
//       </Carousel.Item>
//       <Carousel.Item>
//       <img src={img2} width="100%" height="300"/>
//         <Carousel.Caption>
//           <h3>Second slide label</h3>
//           <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
//         </Carousel.Caption>
//       </Carousel.Item>
//       <Carousel.Item>
//       <img src={img3} width="100%" height="300"/>
//         <Carousel.Caption>
//           <h3>Third slide label</h3>
//           <p>
//             Praesent commodo cursus magna, vel scelerisque nisl consectetur.
//           </p>
//         </Carousel.Caption>
//       </Carousel.Item>
//     </Carousel>

//    <div style={{display:"flex",justifyContent:"space-around"}}>
  
   
//    <img src={img3}  width="300" height="300"/>
//    </div>

// <div style={{display:"flex",justifyContent:"space-around"}}>
//    <Card style={{ width: '18rem' }}>
//       <Card.Img variant="top" src={img1} />
//       <Card.Body>
//         <Card.Title>Card Title</Card.Title>
//         <Card.Text>
//           Some quick example text to build on the card title and make up the
//           bulk of the card's content.
//         </Card.Text>
//         <Button variant="primary">Go somewhere</Button>
//       </Card.Body>
//     </Card>
//    <Card style={{ width: '18rem' }}>
//       <Card.Img variant="top" src={img1} />
//       <Card.Body>
//         <Card.Title>Card Title</Card.Title>
//         <Card.Text>
//           Some quick example text to build on the card title and make up the
//           bulk of the card's content.
//         </Card.Text>
//         <Button variant="primary">Go somewhere</Button>
//       </Card.Body>
//     </Card>
//    <Card style={{ width: '18rem' }}>
//       <Card.Img variant="top" src={img1} />
//       <Card.Body>
//         <Card.Title>Card Title</Card.Title>
//         <Card.Text>
//           Some quick example text to build on the card title and make up the
//           bulk of the card's content.
//         </Card.Text>
//         <Button variant="primary">Go somewhere</Button>
//       </Card.Body>
//     </Card>
//     </div>
//     </>
//   )
// }
// export default App
//Day 9 HomeWork Task:
