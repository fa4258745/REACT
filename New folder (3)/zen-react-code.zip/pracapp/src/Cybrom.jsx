let Cybrom = () => {
    return (
        <>
            <h1>Cybrom is the Leading Institute</h1>
        </>
    )

}
export default Cybrom