//Appling css through object :
const data={
  color:"green",
  textDecoration:"underline"
}
const BoxTask=()=>{
    return(
        <>
         
         <body
        style={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          height: "97vh",
        }}
      >
        <h1 style={data}>Zainab</h1>
        {/* <h1 id="theme">Zainab from layout</h1> */}
       
        <div
          style={{
            backgroundColor: "yellow",
            height: "200px",
            width: "300px",
            borderRadius: "25px",
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
          }}
        >
          <div
            style={{
              backgroundColor: "red",
              height: "140px",
              width: "250px",
              borderRadius: "25px",
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
            }}
          >
            <div
              style={{
                backgroundColor: "coral",
                height: "90px",
                width: "150px",
                borderRadius: "25px",
                textAlign: "center",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              Cybrom
            </div>
          </div>
        </div>
      </body>
        </>
    )
}
export default BoxTask