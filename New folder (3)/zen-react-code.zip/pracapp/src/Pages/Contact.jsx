const Contact=()=>{
    return(
        <>
        <h1>Contact Content</h1>
        </>
    )
    }
    export default Contact