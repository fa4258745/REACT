const NotFound=()=>{
    return(
        <>
<h1>Error : 404 Not Found</h1>
        </>
    )
}
export default NotFound