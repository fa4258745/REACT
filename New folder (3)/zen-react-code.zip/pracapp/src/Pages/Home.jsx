const Home=()=>{
return(
    <>
    <h1>Home Content</h1>
    </>
)
}
export default Home