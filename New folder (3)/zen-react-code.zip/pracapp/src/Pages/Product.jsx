const Product=()=>{
    return(
        <>
        <h1>Product Content</h1>
        </>
    )
    }
    export default Product