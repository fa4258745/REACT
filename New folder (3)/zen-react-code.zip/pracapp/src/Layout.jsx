import { Link, Outlet } from "react-router-dom"
const Layout=()=>{
    return(
        <>

<Link to="home">Home</Link>
<Link to="about">About</Link>
<Link to="contact">Contact Us</Link>
<Link to="product">Our Products</Link>
<br />
<hr size="4" color="red"/>
<Outlet />
<hr size="4" color="red"/>
<br />
www.mycomany.com All Rights Reserved
        </>
    )
}
export default Layout