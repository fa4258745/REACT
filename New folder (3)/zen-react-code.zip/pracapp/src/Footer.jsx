const Footer=()=>{
    return(
        <h1>Iam Footer</h1>
    )
}
export default Footer