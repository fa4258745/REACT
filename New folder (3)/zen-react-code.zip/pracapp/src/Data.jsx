const Data=()=>{
    return(
        <h1>Data inserted</h1>
    )
}

export default Data