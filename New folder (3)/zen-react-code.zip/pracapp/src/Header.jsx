const Header=()=>{
    return(
        <h1>Iam Header</h1>
    )
}
export default Header